# bubbly > 2024-03-22 2:45pm
https://universe.roboflow.com/bubbly/bubbly-c5dzd

Provided by a Roboflow user
License: CC BY 4.0

